from django.core.management.base import BaseCommand
from backend.users.reconciliation import create_mock_deposit_for_testing, manual_reconcile_deposit
from backend.users.models import Wallet

class Command(BaseCommand):
    help = 'Test the bank reconciliation system'

    def add_arguments(self, parser):
        parser.add_argument(
            '--user-id',
            type=str,
            help='User ID (UUID) to create mock deposit for',
        )
        parser.add_argument(
            '--amount',
            type=float,
            default=100.0,
            help='Amount to deposit (default: 100.0)',
        )
        parser.add_argument(
            '--reference',
            type=str,
            help='Reference code for the deposit',
        )

    def handle(self, *args, **options):
        user_id = options.get('user_id')
        amount = options.get('amount', 100.0)
        reference = options.get('reference')

        if user_id:
            try:
                from django.contrib.auth import get_user_model
                User = get_user_model()
                user = User.objects.get(id=user_id)
                wallet = Wallet.objects.get(user=user)
                self.stdout.write(f"Creating mock deposit for user {wallet.user.username}")
                
                if reference:
                    # Manual reconciliation with specific reference
                    success = manual_reconcile_deposit(wallet.id, amount, reference)
                    if success:
                        self.stdout.write(
                            self.style.SUCCESS(f'✅ Manual reconciliation successful: R{amount} for {wallet.user.username}')
                        )
                    else:
                        self.stdout.write(
                            self.style.ERROR('❌ Manual reconciliation failed')
                        )
                else:
                    # Create mock bank transaction
                    create_mock_deposit_for_testing()
                    self.stdout.write(
                        self.style.SUCCESS('✅ Mock deposit created successfully')
                    )
                    
            except Wallet.DoesNotExist:
                self.stdout.write(
                    self.style.ERROR(f'❌ No wallet found for user ID {user_id}')
                )
        else:
            # Create mock deposit for first available wallet
            self.stdout.write("Creating mock deposit for first available wallet...")
            create_mock_deposit_for_testing()
            self.stdout.write(
                self.style.SUCCESS('✅ Mock deposit created successfully')
            )

        # Show current wallet balances
        self.stdout.write("\n📊 Current Wallet Balances:")
        wallets = Wallet.objects.all()[:5]  # Show first 5 wallets
        for wallet in wallets:
            self.stdout.write(
                f"  {wallet.user.username}: {wallet.credits} credits (R{wallet.balance}) - Code: {wallet.customer_code}"
            )
