from django.urls import re_path
from . import consumers

websocket_urlpatterns = [
    # User-specific WebSocket patterns can be added here if needed
    # Lead WebSocket patterns are handled by the leads app
]
