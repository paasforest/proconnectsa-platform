from django.test import TestCase
from django.urls import reverse
from rest_framework.test import APITestCase
from rest_framework import status
from django.contrib.auth import get_user_model
from rest_framework.authtoken.models import Token
from backend.leads.models import ServiceCategory, Lead
from backend.payments.models import ManualDeposit
import json

User = get_user_model()

class APITestCase(APITestCase):
    def setUp(self):
        """Set up test data"""
        # Create test users
        self.client_user = User.objects.create_user(
            username='client@test.com',
            email='client@test.com',
            password='testpass123',
            first_name='Test',
            last_name='Client',
            phone='+27812345678',
            user_type='client',
            city='Cape Town',
            suburb='Sea Point'
        )
        
        self.provider_user = User.objects.create_user(
            username='provider@test.com',
            email='provider@test.com',
            password='testpass123',
            first_name='Test',
            last_name='Provider',
            phone='+27812345679',
            user_type='provider',
            city='Cape Town',
            suburb='Sea Point'
        )
        
        # Create tokens
        self.client_token = Token.objects.create(user=self.client_user)
        self.provider_token = Token.objects.create(user=self.provider_user)
        
        # Create service category
        self.category = ServiceCategory.objects.create(
            name='Test Category',
            slug='test-category',
            description='Test description',
            icon='wrench'
        )

    def test_service_categories_list(self):
        """Test service categories endpoint"""
        url = reverse('service-categories')
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertGreater(len(response.data['results']), 0)

    def test_user_registration(self):
        """Test user registration"""
        url = reverse('user-register')
        data = {
            'first_name': 'New',
            'last_name': 'User',
            'email': 'newuser@test.com',
            'phone': '+27812345680',
            'password': 'testpass123',
            'confirmPassword': 'testpass123',
            'user_type': 'client',
            'city': 'Cape Town',
            'suburb': 'Sea Point'
        }
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertTrue(User.objects.filter(email='newuser@test.com').exists())

    def test_user_login(self):
        """Test user login"""
        url = reverse('user-login')
        data = {
            'email': 'client@test.com',
            'password': 'testpass123'
        }
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('token', response.data)

    def test_lead_creation(self):
        """Test lead creation"""
        url = reverse('lead-create')
        data = {
            'service_category': self.category.id,
            'title': 'Test Lead',
            'description': 'Test lead description',
            'location_city': 'Cape Town',
            'location_suburb': 'Sea Point',
            'budget_range': '1000-5000',
            'urgency': 'medium',
            'preferred_contact_time': 'morning'
        }
        
        # Authenticate as client
        self.client.credentials(HTTP_AUTHORIZATION=f'Token {self.client_token.key}')
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertTrue(Lead.objects.filter(title='Test Lead').exists())

    def test_manual_deposit_creation(self):
        """Test manual deposit creation"""
        url = reverse('manual-deposit-create')
        data = {
            'amount': 500.00,
            'credits_to_activate': 5
        }
        
        # Authenticate as provider
        self.client.credentials(HTTP_AUTHORIZATION=f'Token {self.provider_token.key}')
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertTrue(ManualDeposit.objects.filter(provider=self.provider_user).exists())

    def test_manual_deposit_list(self):
        """Test manual deposit listing"""
        # Create a manual deposit
        ManualDeposit.create_deposit(
            provider=self.provider_user,
            amount=500.00,
            credits_to_activate=5
        )
        
        url = reverse('manual-deposit-list')
        self.client.credentials(HTTP_AUTHORIZATION=f'Token {self.provider_token.key}')
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertGreater(len(response.data['results']), 0)

    def test_unauthorized_access(self):
        """Test unauthorized access to protected endpoints"""
        url = reverse('manual-deposit-list')
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_invalid_data_validation(self):
        """Test input validation"""
        url = reverse('user-registration')
        data = {
            'first_name': '',  # Invalid: empty
            'last_name': 'User',
            'email': 'invalid-email',  # Invalid: not an email
            'phone': '123',  # Invalid: not SA format
            'password': '123',  # Invalid: too short
            'confirmPassword': '456',  # Invalid: doesn't match
            'user_type': 'invalid',  # Invalid: not in choices
            'city': 'Cape Town',
            'suburb': 'Sea Point'
        }
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('first_name', response.data)
        self.assertIn('email', response.data)
        self.assertIn('phone', response.data)
        self.assertIn('password', response.data)
