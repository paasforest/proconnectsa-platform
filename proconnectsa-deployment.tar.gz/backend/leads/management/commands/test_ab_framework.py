from django.core.management.base import BaseCommand
from backend.leads.ab_testing import ABTestFramework, ABTestGroup, ABTestResult
from backend.leads.models import Lead
from backend.users.models import User
import json

class Command(BaseCommand):
    help = 'Test A/B testing framework functionality'

    def add_arguments(self, parser):
        parser.add_argument(
            '--test-name',
            type=str,
            default='lead_scoring_ml_vs_rules',
            help='Test name to run'
        )
        parser.add_argument(
            '--users',
            type=int,
            default=10,
            help='Number of test users to create'
        )
        parser.add_argument(
            '--format',
            type=str,
            default='table',
            choices=['table', 'json'],
            help='Output format'
        )

    def handle(self, *args, **options):
        test_name = options['test_name']
        num_users = options['users']
        output_format = options['format']
        
        self.stdout.write(f"\n🧪 A/B Testing Framework Test")
        self.stdout.write("=" * 50)
        
        # Test user assignment
        self.stdout.write(f"\n📊 Testing User Assignment for '{test_name}'")
        self.stdout.write("-" * 30)
        
        # Create test users
        test_users = []
        for i in range(num_users):
            user_id = f"test_user_{i}"
            group = ABTestFramework.assign_user_to_group(user_id, test_name)
            test_users.append({'user_id': user_id, 'group': group})
            
            if output_format == 'table':
                self.stdout.write(f"User {user_id}: {group}")
        
        # Show group distribution
        group_counts = {}
        for user in test_users:
            group = user['group']
            group_counts[group] = group_counts.get(group, 0) + 1
        
        self.stdout.write(f"\n📈 Group Distribution:")
        for group, count in group_counts.items():
            percentage = (count / num_users) * 100
            self.stdout.write(f"  {group}: {count} users ({percentage:.1f}%)")
        
        # Test event tracking
        self.stdout.write(f"\n📝 Testing Event Tracking")
        self.stdout.write("-" * 30)
        
        # Simulate some events
        events_tracked = 0
        for user in test_users[:5]:  # Track events for first 5 users
            user_id = user['user_id']
            
            # Simulate lead view
            ABTestFramework.track_event(user_id, test_name, 'lead_view')
            events_tracked += 1
            
            # Simulate credit purchase (only for some users)
            if user['group'] == 'ml_treatment':
                ABTestFramework.track_event(user_id, test_name, 'credit_purchase', 50.0)
                events_tracked += 1
            
            # Simulate job completion (only for some users)
            if user_id.endswith('0') or user_id.endswith('5'):  # Every 5th user
                ABTestFramework.track_event(user_id, test_name, 'job_completion', 500.0)
                events_tracked += 1
        
        self.stdout.write(f"Tracked {events_tracked} events")
        
        # Test results analysis
        self.stdout.write(f"\n📊 Test Results Analysis")
        self.stdout.write("-" * 30)
        
        try:
            results = ABTestFramework.get_test_results(test_name, days_back=1)
            
            if output_format == 'json':
                self.stdout.write(json.dumps(results, indent=2))
            else:
                self.print_table_results(results)
                
        except Exception as e:
            self.stdout.write(f"Error getting results: {e}")
        
        # Test user group lookup
        self.stdout.write(f"\n🔍 Testing User Group Lookup")
        self.stdout.write("-" * 30)
        
        test_user_groups = ABTestFramework.get_user_test_groups('test_user_0')
        self.stdout.write(f"User test_user_0 groups: {test_user_groups}")
        
        # Test active status
        is_active = ABTestFramework.is_test_active(test_name)
        self.stdout.write(f"Test '{test_name}' active: {is_active}")
        
        self.stdout.write(f"\n✅ A/B Testing Framework Test Complete!")
        self.stdout.write("=" * 50)

    def print_table_results(self, results):
        """Print results in table format"""
        analysis = results.get('analysis', {})
        raw_data = results.get('raw_data', {})
        
        if not analysis:
            self.stdout.write("No analysis data available")
            return
        
        self.stdout.write(f"\nConversion Rates by Group:")
        self.stdout.write(f"{'Group':<15} {'Lead→Purchase':<15} {'Purchase→Job':<15} {'Overall':<15} {'Revenue':<15}")
        self.stdout.write("-" * 75)
        
        for group, metrics in analysis.items():
            self.stdout.write(f"{group:<15} {metrics['lead_view_to_purchase_rate']:<15.1f}% "
                            f"{metrics['purchase_to_completion_rate']:<15.1f}% "
                            f"{metrics['overall_conversion_rate']:<15.1f}% "
                            f"R{metrics['total_revenue']:<14.2f}")
        
        self.stdout.write(f"\nRaw Event Data:")
        for group, events in raw_data.items():
            self.stdout.write(f"\n{group}:")
            for event_type, data in events.items():
                self.stdout.write(f"  {event_type}: {data['count']} events, "
                                f"avg: {data['avg_value']:.2f}, "
                                f"users: {data['unique_users']}")


