from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from backend.payments.models import DepositRequest, Transaction, PaymentAccount
from backend.users.models import ProviderProfile
from backend.payments.invoice_service import InvoiceService
from backend.payments.auto_deposit_service import AutoDepositService
import logging

User = get_user_model()
logger = logging.getLogger(__name__)

class Command(BaseCommand):
    help = 'Test credit purchase and invoice generation flow'

    def handle(self, *args, **options):
        self.stdout.write("🧪 Testing Credit Purchase Flow")
        self.stdout.write("=" * 50)
        
        # 1. Create or get a test provider
        try:
            provider_user = User.objects.filter(user_type='provider').first()
            if not provider_user:
                self.stdout.write(self.style.ERROR("❌ No provider users found. Please create a provider first."))
                return
                
            self.stdout.write(self.style.SUCCESS(f"✅ Using provider: {provider_user.email}"))
            
            # Get or create payment account
            account, created = PaymentAccount.objects.get_or_create(user=provider_user)
            if created:
                self.stdout.write(self.style.SUCCESS(f"✅ Created payment account for {provider_user.email}"))
            else:
                self.stdout.write(self.style.SUCCESS(f"✅ Found existing payment account: R{account.balance}"))
                
            # Get provider profile
            try:
                provider_profile = provider_user.provider_profile
                self.stdout.write(self.style.SUCCESS(f"✅ Provider profile: {provider_profile.subscription_tier}"))
            except:
                self.stdout.write(self.style.ERROR("❌ No provider profile found"))
                return
                
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"❌ Error setting up provider: {e}"))
            return
        
        # 2. Test manual deposit request creation
        self.stdout.write("\n📝 Testing Manual Deposit Request Creation")
        self.stdout.write("-" * 40)
        
        try:
            # Create a deposit request
            deposit = DepositRequest.objects.create(
                account=account,
                amount=250.00,  # R250 for 5 credits at R50 each
                customer_code=provider_profile.customer_code or "TEST001",
                credits_to_activate=5,
                reference_number=f"PC{DepositRequest.objects.count() + 1:06d}"
            )
            
            self.stdout.write(self.style.SUCCESS(f"✅ Created deposit request: {deposit.id}"))
            self.stdout.write(f"   Amount: R{deposit.amount}")
            self.stdout.write(f"   Credits: {deposit.credits_to_activate}")
            self.stdout.write(f"   Customer Code: {deposit.customer_code}")
            self.stdout.write(f"   Reference: {deposit.reference_number}")
            
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"❌ Error creating deposit request: {e}"))
            return
        
        # 3. Test invoice generation
        self.stdout.write("\n📄 Testing Invoice Generation")
        self.stdout.write("-" * 40)
        
        try:
            invoice_service = InvoiceService()
            invoice_result = invoice_service.generate_invoice(deposit, 'manual_deposit')
            
            if invoice_result['success']:
                self.stdout.write(self.style.SUCCESS("✅ Invoice generated successfully!"))
                self.stdout.write(f"   Invoice Number: {invoice_result['invoice_number']}")
                self.stdout.write(f"   Total Amount: R{invoice_result['invoice_data']['total']}")
                self.stdout.write(f"   Credits: {invoice_result['invoice_data']['credits']}")
                self.stdout.write(f"   Rate: R{invoice_result['invoice_data']['rate_per_credit']} per credit")
            else:
                self.stdout.write(self.style.ERROR(f"❌ Invoice generation failed: {invoice_result['error']}"))
                return
                
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"❌ Error generating invoice: {e}"))
            return
        
        # 4. Test invoice email sending
        self.stdout.write("\n📧 Testing Invoice Email Sending")
        self.stdout.write("-" * 40)
        
        try:
            email_sent = invoice_service.send_invoice_email(
                deposit=deposit,
                invoice_data=invoice_result['invoice_data'],
                html_content=invoice_result['html_content'],
                text_content=invoice_result['text_content']
            )
            
            if email_sent:
                self.stdout.write(self.style.SUCCESS(f"✅ Invoice email sent to {provider_user.email}"))
            else:
                self.stdout.write(self.style.WARNING("⚠️  Invoice email sending failed (check email settings)"))
                
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"❌ Error sending invoice email: {e}"))
        
        # 5. Test auto-deposit processing
        self.stdout.write("\n🔄 Testing Auto-Deposit Processing")
        self.stdout.write("-" * 40)
        
        try:
            auto_deposit_service = AutoDepositService()
            auto_result = auto_deposit_service.process_deposit_by_customer_code(
                customer_code=deposit.customer_code,
                amount=float(deposit.amount),
                reference_number=deposit.reference_number
            )
            
            if auto_result['success']:
                self.stdout.write(self.style.SUCCESS("✅ Auto-deposit processed successfully!"))
                self.stdout.write(f"   Credits activated: {auto_result['credits_activated']}")
                self.stdout.write(f"   New balance: {auto_result['new_credit_balance']}")
            else:
                self.stdout.write(self.style.ERROR(f"❌ Auto-deposit failed: {auto_result['error']}"))
                
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"❌ Error processing auto-deposit: {e}"))
        
        # 6. Verify final state
        self.stdout.write("\n✅ Final Verification")
        self.stdout.write("-" * 40)
        
        try:
            # Refresh from database
            deposit.refresh_from_db()
            account.refresh_from_db()
            provider_profile.refresh_from_db()
            
            self.stdout.write(f"Deposit Status: {deposit.status}")
            self.stdout.write(f"Account Balance: R{account.balance}")
            self.stdout.write(f"Provider Credits: {provider_profile.credit_balance}")
            
            # Check if credits were activated
            if provider_profile.credit_balance >= deposit.credits_to_activate:
                self.stdout.write(self.style.SUCCESS("✅ Credits successfully activated!"))
            else:
                self.stdout.write(self.style.WARNING("⚠️  Credits not yet activated"))
                
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"❌ Error in final verification: {e}"))
        
        self.stdout.write("\n🎉 Credit Purchase Flow Test Complete!")
