#!/usr/bin/env python3
"""
Test SendGrid Email Integration for ProConnectSA
Run this script to test email delivery
"""
import os
import sys
import django

# Setup Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'backend.procompare.settings')
sys.path.append('/home/paas/work_platform')
sys.path.append('/home/paas/work_platform/backend')

django.setup()

from backend.utils.sendgrid_service import sendgrid_service
from django.contrib.auth import get_user_model

def test_sendgrid_integration():
    """Test SendGrid email integration"""
    print("🧪 Testing SendGrid Email Integration for ProConnectSA")
    print("=" * 60)
    
    # Test email address (replace with your email)
    test_email = input("Enter your test email address: ").strip()
    
    if not test_email or '@' not in test_email:
        print("❌ Invalid email address provided")
        return
    
    print(f"\n📧 Sending test email to: {test_email}")
    
    # Test basic email delivery
    success = sendgrid_service.test_email_delivery(test_email)
    
    if success:
        print("✅ SendGrid email test successful!")
        print("✅ Check your inbox for the test email")
        print("\n🎉 Your ProConnectSA email system is ready for production!")
        
        # Test additional email types
        print("\n📋 Testing additional email templates...")
        
        # Create a test user for welcome email
        User = get_user_model()
        test_user = User(
            email=test_email,
            first_name="Test",
            last_name="User"
        )
        
        # Test welcome email
        welcome_success = sendgrid_service.send_welcome_email(test_user)
        if welcome_success:
            print("✅ Welcome email template test successful!")
        else:
            print("❌ Welcome email template test failed")
            
        # Test verification email
        verification_success = sendgrid_service.send_verification_email(test_user, "123456")
        if verification_success:
            print("✅ Verification email template test successful!")
        else:
            print("❌ Verification email template test failed")
            
    else:
        print("❌ SendGrid email test failed!")
        print("❌ Check your SendGrid API key and configuration")
        
        # Troubleshooting information
        print("\n🔧 Troubleshooting:")
        print("1. Verify your SendGrid API key is correct")
        print("2. Check that your sender email is verified in SendGrid")
        print("3. Ensure your .env file has the correct SendGrid settings")
        print("4. Check the Django logs for detailed error messages")

if __name__ == "__main__":
    test_sendgrid_integration()




