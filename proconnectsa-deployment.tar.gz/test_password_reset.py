#!/usr/bin/env python
"""
Test script for password reset functionality
"""
import os
import sys
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'backend.procompare.settings')
django.setup()

def test_password_reset():
    print('🧪 Testing Password Reset System...')
    print('=' * 50)
    
    # Test 1: Check if verification service exists
    try:
        from backend.users.verification_service import VerificationService
        verification_service = VerificationService()
        print('✅ VerificationService imported successfully')
    except Exception as e:
        print(f'❌ VerificationService import failed: {e}')
        return False
    
    # Test 2: Check if we have test users
    from django.contrib.auth import get_user_model
    User = get_user_model()
    
    test_email = 'lisa.security@test.com'
    try:
        user = User.objects.get(email=test_email)
        print(f'✅ Test user found: {user.email}')
        print(f'   - User type: {user.user_type}')
        print(f'   - Is active: {user.is_active}')
    except User.DoesNotExist:
        print(f'❌ Test user {test_email} not found')
        # List available users
        users = User.objects.all()[:5]
        print('Available users:')
        for u in users:
            print(f'   - {u.email} ({u.user_type})')
        return False
    
    # Test 3: Test password reset initiation
    try:
        print('\n🔄 Testing password reset initiation...')
        result = verification_service.initiate_password_reset(test_email, 'email')
        print(f'✅ Password reset initiated: {result}')
        
        if result.get('success'):
            print(f'   - Token: {result.get("token", "N/A")[:20]}...')
            print(f'   - Message: {result.get("message", "N/A")}')
        else:
            print(f'   - Error: {result.get("error", "Unknown error")}')
            
    except Exception as e:
        print(f'❌ Password reset failed: {e}')
        import traceback
        traceback.print_exc()
        return False
    
    print('\n✅ Password reset system test completed successfully!')
    return True

if __name__ == '__main__':
    success = test_password_reset()
    sys.exit(0 if success else 1)




